﻿# -*- coding: utf-8 -*-
"""
Hilltop Collection Import Tool
=============================

ArcGIS Python Toolbox (.pyt) that:

  0. Lets the user pick which council's Hilltop server to use:
        - Horizons Regional Council
        - Greater Wellington Regional Council (GWRC)
        - Taranaki Regional Council (TRC)
        - Northland Regional Council (NRC)
        - Southland Regional Council (Environment Southland)
     Every dropdown, cache, and download below is scoped to the chosen
     council. As soon as a council is picked, the active map is zoomed to
     a fixed WGS 1984 bounding box for that council's region.
  1. Downloads that council's Hilltop "CollectionList" and builds a
     dropdown of available collections. As soon as a collection is
     picked, all of the sites in that collection are added to the map.
  2. Builds the Sites list for the chosen collection by MERGING two
     services: CollectionList (which sites/measurements belong to the
     collection) and SiteList (Location=LatLong, where those sites are).
  3. Optionally, an extent drawn on the map (WGS 1984) restricts both the
     Measurement and Sites lists to sites inside it.
  4. After a measurement is selected, the Sites table is narrowed to sites
     that have that measurement. The sites chosen are also selected on the
     map, in the CollectionSites layer.
  5. Creates a SITES-ONLY point feature class (one point per selected
     site), in WGS 1984.
  6. Optionally creates a RECORDINGS TABLE in the same geodatabase
     (<Feature Class Name>_Recordings) holding the recordings for the
     selected sites, linked to the feature class by SiteName.
  7. Adds the feature class and the table to an existing open map or to a
     brand new map, chosen by the user.

Recordings table content:
  - "Include Last Recording": the latest value per selected site/measurement.
  - "Save Time Series To Table": every recording in the chosen From/To date
    range (Hilltop GetData with From/To parameters).
  - Optionally the time series is also exported to a CSV file.

Feature class fields:
        SiteName, Longitude, Latitude, CollectionName, Council

Recordings table fields:
        SiteName, MeasurementName, Units, MeasurementTime (DATE),
        MeasurementValue (DOUBLE), CollectionName, Council

Council services (CollectionList / SiteList / GetData):
    Horizons   http://hilltopserver.horizons.govt.nz/data.hts
    GWRC       https://hilltop.gw.govt.nz/data.hts
    TRC        https://extranet.trc.govt.nz/getdata/boo.hts
    NRC        https://hilltop.nrc.govt.nz/data.hts
    Southland  http://odp.es.govt.nz/data.hts
"""

import arcpy
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import codecs
import gzip
import os
import re
import csv
import logging
import time
import traceback
from datetime import datetime


# ---------------------------------------------------------------------------
# Persistent debug logging for dropdown / collection-list diagnostics
# ---------------------------------------------------------------------------
# Separate from the per-run log created in execute(). updateParameters()
# fires whenever the dialog is edited, long before Run, so it needs its own
# module-level logger writing to a fixed file next to this .pyt.

_LOG_DIR = os.path.dirname(__file__)
_DEBUG_LOG_FILE = os.path.join(_LOG_DIR, "HilltopToolbox_debug.log")

_debug_logger = logging.getLogger("HilltopToolbox.debug")
_debug_logger.setLevel(logging.DEBUG)

# Avoid duplicate handlers if ArcGIS Pro reloads this module.
if not _debug_logger.handlers:
    _debug_handler = logging.FileHandler(_DEBUG_LOG_FILE, encoding="utf-8")
    _debug_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    )
    _debug_logger.addHandler(_debug_handler)

_debug_logger.info(
    "Toolbox module (re)loaded from %s", os.path.abspath(__file__)
)


# ---------------------------------------------------------------------------
# Council -> service URL configuration
# ---------------------------------------------------------------------------

HORIZONS = "Manawatū-Whanganui Region"
GWRC = "Greater Wellington Region"
TRC = "Taranaki Region"
NRC = "Northland Region"
SOUTHLAND = "Southland Region"

COUNCIL_NAMES = [HORIZONS, GWRC, TRC, NRC, SOUTHLAND]

COUNCIL_URLS = {
    HORIZONS: {
        "collection": (
            "http://hilltopserver.horizons.govt.nz/"
            "data.hts?Service=Hilltop&Request=CollectionList"
        ),
        "sites": (
            "https://hilltopserver.horizons.govt.nz/"
            "data.hts?Service=Hilltop&Request=SiteList&Location=LatLong"
        ),
        "getdata": (
            "https://hilltopserver.horizons.govt.nz/"
            "data.hts?Service=Hilltop&Request=GetData&Collection="
        ),
    },
    GWRC: {
        "collection": (
            "https://hilltop.gw.govt.nz/"
            "data.hts?Service=Hilltop&Request=CollectionList"
        ),
        "sites": (
            "https://hilltop.gw.govt.nz/"
            "data.hts?Service=Hilltop&Request=SiteList&Location=LatLong"
        ),
        "getdata": (
            "https://hilltop.gw.govt.nz/"
            "data.hts?Service=Hilltop&Request=GetData&Collection="
        ),
    },
    TRC: {
        "collection": (
            "https://extranet.trc.govt.nz/getdata/"
            "boo.hts?Service=Hilltop&Request=CollectionList"
        ),
        "sites": (
            "https://extranet.trc.govt.nz/getdata/"
            "boo.hts?Service=Hilltop&Request=SiteList&Location=LatLong"
        ),
        "getdata": (
            "https://extranet.trc.govt.nz/getdata/"
            "boo.hts?Service=Hilltop&Request=GetData&Collection="
        ),
    },
    NRC: {
        "collection": (
            "https://hilltop.nrc.govt.nz/"
            "data.hts?Service=Hilltop&Request=CollectionList"
        ),
        "sites": (
            "https://hilltop.nrc.govt.nz/"
            "data.hts?Service=Hilltop&Request=SiteList&Location=LatLong"
        ),
        "getdata": (
            "https://hilltop.nrc.govt.nz/"
            "data.hts?Service=Hilltop&Request=GetData&Collection="
        ),
    },
    SOUTHLAND: {
        "collection": (
            "http://odp.es.govt.nz/"
            "data.hts?Service=Hilltop&Request=CollectionList"
        ),
        "sites": (
            "http://odp.es.govt.nz/"
            "data.hts?Service=Hilltop&Request=SiteList&Location=LatLong"
        ),
        "getdata": (
            "http://odp.es.govt.nz/"
            "data.hts?Service=Hilltop&Request=GetData&Collection="
        ),
    },
}

# Fixed WGS 1984 bounding boxes (min_lon, min_lat, max_lon, max_lat) used
# to zoom the map to a council's region as soon as it's selected.
COUNCIL_BOUNDING_BOXES_WGS84 = {
    GWRC: (174.570, -41.809, 176.375, -40.380),
    SOUTHLAND: (166.452000, -47.588500, 169.458000, -43.944966),
    NRC: (172.61, -36.50, 174.92, -34.37),
    TRC: (173.86, -40.07, 175.05, -38.69),
    HORIZONS: (174.60, -41.55, 176.85, -37.05),
}

HTTP_TIMEOUT = 60
USER_AGENT = "Mozilla/5.0 (ArcGIS Hilltop Toolbox)"

# WGS 1984 (WKID 4326) is used throughout: feature class, any map this
# tool creates, and the extent filter's coordinates.
WGS84_WKID = 4326


def _wgs84_spatial_reference():
    """Return a fresh arcpy.SpatialReference for WGS 1984 (WKID 4326)."""
    return arcpy.SpatialReference(WGS84_WKID)


# Hilltop's From/To query parameters are Day/Month/Year.
HILLTOP_DATE_FORMAT = "%d/%m/%Y"

LONG_RANGE_WARNING_DAYS = 90
VERY_LONG_RANGE_WARNING_DAYS = 365

# Module-level caches, keyed by council so switching councils never mixes
# data between them.
_COLLECTION_NAMES_CACHE = {}      # {council: [names, ...]}
_SITE_COORD_CACHE = {}            # {council: {site_name: (lat, lon)}}
_COLLECTION_ITEMS_CACHE = {}      # {(council, collection_name): [(site, meas), ...]}
_LAST_MEASUREMENT_CACHE = {}      # {(council, collection_name): [records, ...]}

# Most recent fetch failure per (council, request kind).
_LAST_FETCH_ERROR = {}            # {(council, "collection"|"sites"): str}

# Which council the active map was last zoomed to (once per selection).
_ZOOM_STATE = {"council": None}

# Tracks the automatically-created CollectionSites feature class so
# updateParameters() does not recreate it on every validation pass.
_INITIAL_FC_STATE = {"key": None, "path": None, "map_name": None}

# Last site selection pushed to the CollectionSites layer.
_SELECTION_STATE = {"key": None}


def _record_fetch_error(council, kind, exc):
    _LAST_FETCH_ERROR[(council, kind)] = "{}: {}".format(
        type(exc).__name__, exc
    )


def get_last_fetch_error(council, kind):
    """Return the last recorded error string for (council, kind), or None."""
    return _LAST_FETCH_ERROR.get((council, kind))


# One opener that explicitly honours proxy environment variables / the
# system proxy settings (important on locked-down council networks).
_PROXY_HANDLER = urllib.request.ProxyHandler(urllib.request.getproxies())
_OPENER = urllib.request.build_opener(_PROXY_HANDLER)


def _fetch_xml(url, timeout=HTTP_TIMEOUT):
    """Download and parse an XML document from a Hilltop service.

    Every attempt is recorded in the persistent debug log. The response is
    defended against two things some Hilltop servers do:
      - sending a gzip-compressed body without being asked (urllib does
        not auto-decode it, and the gzip magic bytes make the XML parser
        fail with "not well-formed ... line 1, column 0");
      - prepending a UTF-8 BOM before the <?xml ...?> declaration, which
        ElementTree does not tolerate.
    """

    start = time.monotonic()

    _debug_logger.info("Fetch start: url=%s timeout=%s", url, timeout)

    try:

        request = urllib.request.Request(
            url,
            headers={"User-Agent": USER_AGENT},
        )
        response = _OPENER.open(request, timeout=timeout)
        xml_bytes = response.read()

        elapsed = time.monotonic() - start

        _debug_logger.info(
            "Fetch success: url=%s elapsed=%.2fs bytes=%d",
            url, elapsed, len(xml_bytes),
        )

        content_encoding = response.headers.get(
            "Content-Encoding", ""
        ).lower()

        if "gzip" in content_encoding or xml_bytes[:2] == b"\x1f\x8b":
            _debug_logger.info(
                "Fetch: response for url=%s is gzip-compressed "
                "(Content-Encoding=%r) - decompressing",
                url, content_encoding,
            )
            xml_bytes = gzip.decompress(xml_bytes)
            _debug_logger.info(
                "Fetch: decompressed to %d bytes", len(xml_bytes)
            )

        if xml_bytes.startswith(codecs.BOM_UTF8):
            _debug_logger.info(
                "Fetch: stripped a leading UTF-8 BOM from url=%s", url
            )
            xml_bytes = xml_bytes[len(codecs.BOM_UTF8):]

        try:
            return ET.fromstring(xml_bytes)
        except ET.ParseError:
            # Log a snippet of what was actually returned (HTML error
            # page, proxy interstitial, truncated response, ...).
            snippet = xml_bytes[:1000]
            _debug_logger.error(
                "XML parse error for url=%s elapsed=%.2fs bytes=%d\n"
                "First 1000 bytes of response (repr):\n%r\n%s",
                url, elapsed, len(xml_bytes), snippet,
                traceback.format_exc(),
            )
            raise

    except Exception:

        elapsed = time.monotonic() - start

        _debug_logger.error(
            "Fetch FAILED: url=%s timeout=%s elapsed=%.2fs\n%s",
            url, timeout, elapsed, traceback.format_exc(),
        )
        raise


def _get_name(element):
    """
    Return an element's "Name", checking both a Name attribute and a
    <Name> child element, since different Hilltop server versions expose
    it differently. Returns None if neither form is present.
    """

    name = element.get("Name")
    if name:
        return name.strip()

    name_child = element.find("Name")
    if name_child is not None and name_child.text:
        return name_child.text.strip()

    return None


def get_collection_names(council):
    """Return the list of collection names for the given council."""

    cached = _COLLECTION_NAMES_CACHE.get(council)
    if cached is not None:
        return cached

    try:
        root = _fetch_xml(COUNCIL_URLS[council]["collection"])
    except Exception as exc:
        _record_fetch_error(council, "collection", exc)
        raise

    names = []
    seen = set()

    for collection in root.findall(".//Collection"):
        name = _get_name(collection)
        if name and name not in seen:
            seen.add(name)
            names.append(name)

    names.sort(key=lambda n: n.lower())

    _debug_logger.info(
        "get_collection_names(%s): parsed %d unique collection name(s)",
        council, len(names),
    )

    # Only cache a non-empty result so a transient empty parse can retry.
    if names:
        _COLLECTION_NAMES_CACHE[council] = names
    else:
        _debug_logger.warning(
            "get_collection_names(%s): zero collections parsed from a "
            "successful response - check the XML structure assumption "
            "in _get_name()/root.findall('.//Collection').", council,
        )

    _LAST_FETCH_ERROR.pop((council, "collection"), None)
    return names


def _normalize_site_name(name):
    """
    Normalize a site name for matching purposes only (never for display
    or for building URLs/output values). CollectionList and SiteList names
    can differ in case or incidental whitespace.
    """

    if not name:
        return ""

    return re.sub(r"\s+", " ", name).strip().casefold()


def get_site_coordinates(council):
    """Build a {site_name: (latitude, longitude)} dict for the council."""

    cached = _SITE_COORD_CACHE.get(council)
    if cached is not None:
        return cached

    try:
        root = _fetch_xml(COUNCIL_URLS[council]["sites"])
    except Exception as exc:
        _record_fetch_error(council, "sites", exc)
        raise

    coords = {}

    for site in root.findall(".//Site"):

        name = _get_name(site)

        if not name:
            continue

        lat_elem = site.find("Latitude")
        lon_elem = site.find("Longitude")

        if lat_elem is None or lon_elem is None:
            continue

        if lat_elem.text is None or lon_elem.text is None:
            continue

        try:
            lat = float(lat_elem.text)
            lon = float(lon_elem.text)
        except (TypeError, ValueError):
            continue

        # Keep the first occurrence; later duplicate names are ignored.
        if name not in coords:
            coords[name] = (lat, lon)

    _debug_logger.info(
        "get_site_coordinates(%s): parsed %d site coordinate(s)",
        council, len(coords),
    )

    if coords:
        _SITE_COORD_CACHE[council] = coords
    else:
        _debug_logger.warning(
            "get_site_coordinates(%s): zero site coordinates parsed from "
            "a successful response - check the XML structure assumption "
            "in _get_name()/root.findall('.//Site').", council,
        )
    _LAST_FETCH_ERROR.pop((council, "sites"), None)
    return coords


def get_normalized_site_coordinates(council):
    """
    Return a {normalized_site_name: (latitude, longitude)} dict built
    from `get_site_coordinates`, keyed by `_normalize_site_name`.
    """

    coords = get_site_coordinates(council)

    normalized = {}
    for name, latlon in coords.items():
        key = _normalize_site_name(name)
        if key and key not in normalized:
            normalized[key] = latlon

    return normalized


def get_collection_items(council, collection_name):
    """
    Return the ordered list of (site_name, measurement) tuples that
    belong to the named collection for the given council, taken from the
    <Item> tags in the CollectionList response.
    """

    cache_key = (council, collection_name)
    if cache_key in _COLLECTION_ITEMS_CACHE:
        return _COLLECTION_ITEMS_CACHE[cache_key]

    try:
        root = _fetch_xml(COUNCIL_URLS[council]["collection"])
    except Exception as exc:
        _record_fetch_error(council, "collection", exc)
        raise

    items = []

    for collection in root.findall(".//Collection"):

        if _get_name(collection) != collection_name:
            continue

        for item in collection.findall("Item"):

            site_name_elem = item.find("SiteName")
            measurement_elem = item.find("Measurement")

            if site_name_elem is None or site_name_elem.text is None:
                continue

            site_name = site_name_elem.text.strip()

            measurement = None
            if (
                measurement_elem is not None
                and measurement_elem.text
            ):
                measurement = measurement_elem.text.strip()

            if site_name:
                items.append((site_name, measurement))

    _COLLECTION_ITEMS_CACHE[cache_key] = items
    return items


def get_collection_site_records(
    council, collection_name, measurement=None, extent_bounds=None
):
    """
    Build the site list for a collection by MERGING CollectionList (which
    sites/measurements belong to the collection) with SiteList (where the
    sites are). A site only appears if it is in both. Matching uses
    `_normalize_site_name`.

    Returns an ordered (by site name) list of dicts:
        {"site_name": str, "latitude": float, "longitude": float}
    using the site name spelling from CollectionList.
    """

    items = get_collection_items(council, collection_name)
    site_coords = get_normalized_site_coordinates(council)

    if extent_bounds is not None:
        min_lon, min_lat, max_lon, max_lat = extent_bounds

    seen = set()
    records = []

    for site_name, meas in items:

        if measurement and meas != measurement:
            continue

        key = _normalize_site_name(site_name)
        if key in seen:
            continue

        coords = site_coords.get(key)
        if coords is None:
            continue

        lat, lon = coords

        if extent_bounds is not None and not (
            min_lon <= lon <= max_lon and min_lat <= lat <= max_lat
        ):
            continue

        seen.add(key)
        records.append(
            {"site_name": site_name, "latitude": lat, "longitude": lon}
        )

    records.sort(key=lambda r: r["site_name"].lower())
    return records


def get_measurements_for_collection(council, collection_name, extent_bounds=None):
    """
    Return the sorted, distinct list of measurement tags in a collection,
    restricted to measurements at sites that have a known location (and,
    optionally, fall inside `extent_bounds`).
    """

    records = get_collection_site_records(
        council, collection_name, extent_bounds=extent_bounds
    )
    locatable_sites = {_normalize_site_name(r["site_name"]) for r in records}

    items = get_collection_items(council, collection_name)

    seen = set()
    measurements = []

    for site_name, measurement in items:

        if _normalize_site_name(site_name) not in locatable_sites:
            continue

        if measurement and measurement not in seen:
            seen.add(measurement)
            measurements.append(measurement)

    measurements.sort(key=lambda m: m.lower())
    return measurements


def get_sites_for_collection(
    council, collection_name, measurement=None, extent_bounds=None
):
    """
    Return the ordered, distinct list of site names for a collection and
    council (see `get_collection_site_records`), optionally filtered by
    measurement and/or extent.
    """

    records = get_collection_site_records(
        council, collection_name, measurement=measurement,
        extent_bounds=extent_bounds,
    )
    return [r["site_name"] for r in records]


def _get_council_extent_wgs84(council):
    """
    Return the fixed arcpy.Extent (WGS 1984) for the given council, from
    `COUNCIL_BOUNDING_BOXES_WGS84`, or None if the council isn't known.
    """

    bounds = COUNCIL_BOUNDING_BOXES_WGS84.get(council)

    if bounds is None:
        _debug_logger.warning(
            "No bounding box configured for council '%s' - cannot zoom.",
            council,
        )
        return None

    min_lon, min_lat, max_lon, max_lat = bounds

    return arcpy.Extent(
        min_lon, min_lat, max_lon, max_lat,
        spatial_reference=_wgs84_spatial_reference(),
    )


def _zoom_active_map_to_extent(extent):
    """
    Best-effort: zoom the active ArcGIS Pro map view's camera to the given
    (WGS 1984) extent. Any failure is logged and swallowed.
    """

    try:
        aprx = arcpy.mp.ArcGISProject("CURRENT")
        active_view = aprx.activeView

        # MapView/Layout objects don't expose ".className"; the presence of
        # ".camera" is the signal that this is a zoomable map view.
        if active_view is None or not hasattr(active_view, "camera"):
            _debug_logger.info(
                "Skipping zoom-to-council-extent: active view has no "
                "camera (not a map view) - activeView=%r", active_view,
            )
            return

        # The camera extent is interpreted in the map's own spatial
        # reference, so reproject when it isn't WGS 1984.
        target_extent = extent
        active_map = getattr(active_view, "map", None) or aprx.activeMap
        if active_map is not None:
            try:
                map_sr = active_map.spatialReference
                if map_sr is not None and map_sr.factoryCode not in (
                    0, WGS84_WKID,
                ):
                    target_extent = extent.projectAs(map_sr)
            except Exception:
                _debug_logger.warning(
                    "Could not reproject council extent to map spatial "
                    "reference - zooming with the raw WGS84 extent "
                    "instead:\n%s", traceback.format_exc(),
                )
                target_extent = extent

        active_view.camera.setExtent(target_extent)

        _debug_logger.info(
            "Zoomed active map to extent: %s, %s, %s, %s",
            target_extent.XMin, target_extent.YMin,
            target_extent.XMax, target_extent.YMax,
        )

    except Exception:
        _debug_logger.warning(
            "Could not zoom active map to council extent:\n%s",
            traceback.format_exc(),
        )


def _extent_to_wgs84_bounds(extent):
    """
    Convert an arcpy.Extent to a (min_lon, min_lat, max_lon, max_lat)
    tuple in WGS84 decimal degrees. Returns None if the extent is missing
    or degenerate (a "no filter" case). Genuine projection failures raise.
    """

    if extent is None:
        return None

    if extent.XMin == extent.XMax or extent.YMin == extent.YMax:
        return None

    wgs84 = _wgs84_spatial_reference()

    src_sr = extent.spatialReference
    needs_projection = (
        src_sr is not None
        and src_sr.factoryCode not in (0, 4326)
    )

    projected = extent.projectAs(wgs84) if needs_projection else extent

    if projected is None:
        raise ValueError("Extent could not be projected to WGS84.")

    return (
        projected.XMin,
        projected.YMin,
        projected.XMax,
        projected.YMax,
    )


def get_extent_bounds_wgs84(extent):
    """Public wrapper around `_extent_to_wgs84_bounds`."""

    return _extent_to_wgs84_bounds(extent)


def _datasource_name_from_measurement_tag(tag):
    """
    A CollectionList <Measurement> tag looks like
        "Rainfall [SCADA Rainfall]"
    The part inside the last [ ... ] is the DataSource name used by the
    GetData service.
    """

    if not tag:
        return None

    if "[" in tag and "]" in tag:
        start = tag.rfind("[")
        end = tag.rfind("]")
        if end > start:
            return tag[start + 1:end].strip()

    return tag.strip()


def _set_map_spatial_reference_wgs84(target_map):
    """
    Set a newly created map's spatial reference to WGS 1984. Only applied
    to maps this tool creates. Failure is a warning, not an error.
    """

    try:
        target_map.spatialReference = _wgs84_spatial_reference()
    except Exception:
        logging.warning(
            "Could not set map '%s' to WGS 1984: %s",
            getattr(target_map, "name", "?"),
            traceback.format_exc(),
        )
        arcpy.AddWarning(
            "Could not set the new map's coordinate system to WGS 1984 - "
            "it will use ArcGIS Pro's default instead. The feature class "
            "itself is still created in WGS 1984."
        )


def _apply_circle3_symbology(layer, size=None):
    """
    Set a point layer's symbology to the "Circle 3" symbol from the
    built-in ArcGIS 2D style. Best-effort: failures are logged and
    swallowed.
    """

    try:
        sym = layer.symbology

        if not layer.isFeatureLayer:
            _debug_logger.warning(
                "Layer '%s' is not a feature layer - cannot set point "
                "symbology.", getattr(layer, "name", "?"),
            )
            return

        if not hasattr(sym, "renderer"):
            _debug_logger.warning(
                "Layer '%s' has no renderer object on its symbology - "
                "leaving default symbology in place.",
                getattr(layer, "name", "?"),
            )
            return

        if sym.renderer.type != "SimpleRenderer":
            sym.updateRenderer("SimpleRenderer")

        applied = False

        # Primary: applySymbolFromGallery() has no style_class argument,
        # so there is no enum value to get wrong.
        try:
            sym.renderer.symbol.applySymbolFromGallery("Circle 3")
            applied = True
        except Exception:
            _debug_logger.warning(
                "applySymbolFromGallery('Circle 3') failed for layer "
                "'%s' - falling back to listStyleItems:\n%s",
                getattr(layer, "name", "?"), traceback.format_exc(),
            )

        if not applied:
            # Fallback: listStyleItems(); the valid style_class value has
            # varied by ArcGIS Pro version, so try the candidates in turn.
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            circle3_symbol = None

            for style_class in ("POINT", "Point Symbols", "Point_Symbols"):
                try:
                    matches = aprx.listStyleItems(
                        "ArcGIS 2D", style_class, "Circle 3"
                    )
                except Exception:
                    continue

                if matches:
                    circle3_symbol = matches[0].symbol
                    break

            if circle3_symbol is not None:
                sym.renderer.symbol = circle3_symbol
                applied = True
            else:
                _debug_logger.warning(
                    "Could not find 'Circle 3' in the ArcGIS 2D style "
                    "gallery via any known style_class value - leaving "
                    "default symbology on layer '%s' in place.",
                    getattr(layer, "name", "?"),
                )
                return

        if size:
            sym.renderer.symbol.size = size

        layer.symbology = sym

        _debug_logger.info(
            "Applied 'Circle 3' point symbology to layer '%s'.",
            getattr(layer, "name", "?"),
        )

    except Exception:
        _debug_logger.warning(
            "Could not apply 'Circle 3' symbology to layer '%s':\n%s",
            getattr(layer, "name", "?"), traceback.format_exc(),
        )


# Gallery symbol name and font settings used for the CollectionSites labels.
LABEL_GALLERY_SYMBOL_NAME = "Point of Interest: POI (black halo)"
LABEL_FONT_FAMILY = "Corbel"
LABEL_FONT_STYLE = "Regular"
LABEL_FONT_SIZE = 8.5
# Label text fill color as [R, G, B, Alpha] (0-255 each). White text with a
# black halo stays readable over light and dark basemaps.
LABEL_TEXT_COLOR_RGBA = [255, 255, 255, 100]


def _apply_sitename_labels(layer):
    """
    Turn on labels for a point layer using the SiteName field, with a
    white, black-halo text symbol at LABEL_FONT_SIZE using
    LABEL_FONT_FAMILY / LABEL_FONT_STYLE.

    This ArcGIS Pro build's LabelClass does NOT expose .textSymbol /
    .symbol (only SQLQuery, expression, expressionEngine, getDefinition,
    name, setDefinition, visible), so the text symbol is read/modified/
    written back through the CIM definition (getDefinition("V3") /
    setDefinition). CIM text symbols use `height` for font size.

    Best-effort: failures are logged and swallowed.
    """

    try:
        if not layer.isFeatureLayer:
            _debug_logger.warning(
                "Layer '%s' is not a feature layer - cannot label it.",
                getattr(layer, "name", "?"),
            )
            return

        label_classes = layer.listLabelClasses()

        if not label_classes:
            _debug_logger.warning(
                "Layer '%s' has no label classes to configure - "
                "leaving labels off.", getattr(layer, "name", "?"),
            )
            return

        for label_class in label_classes:
            try:
                label_class.expressionEngine = "Arcade"
            except Exception:
                pass

            label_class.expression = "$feature.SiteName"
            label_class.visible = True

            try:
                if not hasattr(label_class, "getDefinition"):
                    _debug_logger.warning(
                        "Layer '%s': LabelClass has no getDefinition() - "
                        "cannot configure the label text symbol on this "
                        "ArcGIS Pro version (available attrs: %s).",
                        getattr(layer, "name", "?"),
                        [a for a in dir(label_class) if not a.startswith("_")],
                    )
            except Exception:
                pass

            try:
                try:
                    cim_label_class = label_class.getDefinition("V3")
                except TypeError:
                    cim_label_class = label_class.getDefinition()

                sym_ref = getattr(cim_label_class, "textSymbol", None)
                if sym_ref is None:
                    sym_ref = arcpy.cim.CIMSymbolReference()

                cim_text_symbol = getattr(sym_ref, "symbol", None)
                if cim_text_symbol is None:
                    cim_text_symbol = arcpy.cim.CIMTextSymbol()

                applied_named_style = False

                # Try the exact named gallery symbol first; the manual
                # black halo below is the version-independent fallback.
                try:
                    aprx = arcpy.mp.ArcGISProject("CURRENT")
                    gallery_symbol = None

                    for style_class in (
                        "Text symbols", "TEXT", "Text Symbols",
                        "Text_Symbols",
                    ):
                        try:
                            matches = aprx.listStyleItems(
                                "ArcGIS 2D", style_class,
                                LABEL_GALLERY_SYMBOL_NAME,
                            )
                        except Exception:
                            continue
                        if matches:
                            gallery_symbol = matches[0].symbol
                            break

                    if gallery_symbol is not None:
                        sym_ref.symbol = gallery_symbol
                        cim_text_symbol = sym_ref.symbol
                        applied_named_style = True

                except Exception:
                    _debug_logger.warning(
                        "Could not apply named gallery symbol %r to "
                        "layer '%s' via the CIM label definition - "
                        "falling back to a manually-built black halo:"
                        "\n%s",
                        LABEL_GALLERY_SYMBOL_NAME,
                        getattr(layer, "name", "?"),
                        traceback.format_exc(),
                    )

                if not applied_named_style:
                    try:
                        halo_fill = arcpy.cim.CIMSolidFill()
                        halo_fill.enable = True
                        halo_fill.color = arcpy.cim.CIMRGBColor(
                            values=[0, 0, 0, 100]
                        )

                        halo_symbol = arcpy.cim.CIMPolygonSymbol()
                        halo_symbol.symbolLayers = [halo_fill]

                        cim_text_symbol.haloSymbol = halo_symbol
                        cim_text_symbol.haloSize = 1.5

                    except Exception:
                        _debug_logger.warning(
                            "Could not build a manual black halo for "
                            "layer '%s':\n%s",
                            getattr(layer, "name", "?"),
                            traceback.format_exc(),
                        )

                # White label text, assigned as a plain dict matching the
                # CIM JSON schema (Esri's documented pattern). Building
                # this with arcpy.cim.CIMPolygonSymbol()/CIMSolidFill()
                # objects made labels stop rendering entirely, because
                # those constructors omit schema details the text renderer
                # needs on the main glyph-fill symbol.
                try:
                    cim_text_symbol.symbol = {
                        "type": "CIMPolygonSymbol",
                        "symbolLayers": [
                            {
                                "type": "CIMSolidFill",
                                "enable": True,
                                "color": {
                                    "type": "CIMRGBColor",
                                    "values": LABEL_TEXT_COLOR_RGBA,
                                },
                            }
                        ],
                    }
                except Exception:
                    _debug_logger.warning(
                        "Could not set label text color to white for "
                        "layer '%s':\n%s",
                        getattr(layer, "name", "?"),
                        traceback.format_exc(),
                    )

                cim_text_symbol.fontFamilyName = LABEL_FONT_FAMILY
                cim_text_symbol.fontStyleName = LABEL_FONT_STYLE
                cim_text_symbol.height = LABEL_FONT_SIZE

                sym_ref.symbol = cim_text_symbol
                cim_label_class.textSymbol = sym_ref

                label_class.setDefinition(cim_label_class)

                _debug_logger.info(
                    "Configured label text symbol on layer '%s' via "
                    "CIM: named_style_applied=%s, font=%s %s, size=%s, "
                    "text_color=%s",
                    getattr(layer, "name", "?"), applied_named_style,
                    LABEL_FONT_FAMILY, LABEL_FONT_STYLE, LABEL_FONT_SIZE,
                    LABEL_TEXT_COLOR_RGBA,
                )

            except Exception:
                _debug_logger.warning(
                    "Could not configure the label text symbol (CIM) "
                    "on layer '%s':\n%s",
                    getattr(layer, "name", "?"), traceback.format_exc(),
                )

        layer.showLabels = True

        _debug_logger.info(
            "Enabled SiteName labels on layer '%s'.",
            getattr(layer, "name", "?"),
        )

    except Exception:
        _debug_logger.warning(
            "Could not enable SiteName labels on layer '%s':\n%s",
            getattr(layer, "name", "?"), traceback.format_exc(),
        )


def _find_layer_by_datasource(target_map, data_source_path):
    """
    Return the first layer in `target_map` whose dataSource matches
    `data_source_path`, or None.
    """

    for layer in target_map.listLayers():
        try:
            if getattr(layer, "dataSource", None) == data_source_path:
                return layer
        except Exception:
            continue
    return None


def _find_table_by_datasource(target_map, data_source_path):
    """
    Return the first standalone table in `target_map` whose dataSource
    matches `data_source_path`, or None. Used so re-running the tool does
    not add the same recordings table to the map twice.
    """

    try:
        for tbl in target_map.listTables():
            try:
                if getattr(tbl, "dataSource", None) == data_source_path:
                    return tbl
            except Exception:
                continue
    except Exception:
        pass
    return None


def _site_names_from_param(param):
    """
    Return the de-duplicated list of site names chosen in the Sites
    parameter (a one-column value table, so `.values` is a list of rows).
    Blank rows are skipped.
    """

    names = []
    values = param.values
    if not values:
        return names

    for row in values:
        value = row[0] if isinstance(row, (list, tuple)) else row
        if value is None:
            continue
        value = str(value).strip().strip("'\"")
        if value:
            names.append(value)

    return list(dict.fromkeys(names))


def _refresh_map_display():
    """
    Best-effort: force ArcGIS Pro to repaint the active map view and the
    Contents pane so a selection made from inside the tool dialog shows up
    immediately. Failures are ignored.
    """

    try:
        arcpy.RefreshActiveView()
    except Exception:
        _debug_logger.info("RefreshActiveView failed:\n%s", traceback.format_exc())

    try:
        arcpy.RefreshTOC()
    except Exception:
        _debug_logger.info("RefreshTOC failed:\n%s", traceback.format_exc())

    # Camera nudge: re-applying the view's own extent makes ArcGIS Pro
    # redraw even when RefreshActiveView() is ignored while the dialog is
    # busy. The view doesn't visibly move.
    try:
        aprx = arcpy.mp.ArcGISProject("CURRENT")
        active_view = aprx.activeView
        if active_view is not None and hasattr(active_view, "camera"):
            camera = active_view.camera
            camera.setExtent(camera.getExtent())
    except Exception:
        _debug_logger.info(
            "Camera nudge failed:\n%s", traceback.format_exc()
        )


def _select_sites_in_collection_layer(site_names):
    """
    Best-effort: select the given sites (by SiteName) in the
    CollectionSites layer on the map. An empty list clears the selection.
    Returns True if applied, False if it could not be (so the caller can
    retry on a later updateParameters pass).
    """

    try:
        path = _INITIAL_FC_STATE.get("path")
        if not path or not arcpy.Exists(path):
            return False

        aprx = arcpy.mp.ArcGISProject("CURRENT")

        candidate_maps = []
        map_name = _INITIAL_FC_STATE.get("map_name")
        if map_name:
            candidate_maps = [m for m in aprx.listMaps() if m.name == map_name]
        if not candidate_maps and aprx.activeMap is not None:
            candidate_maps = [aprx.activeMap]

        layer = None
        for candidate in candidate_maps:
            layer = _find_layer_by_datasource(candidate, path)
            if layer is not None:
                break

        if layer is None:
            _debug_logger.info(
                "Select sites: CollectionSites layer not found in the map "
                "yet (path=%s) - will retry.", path,
            )
            return False

        oids = []
        if site_names:
            field = arcpy.AddFieldDelimiters(path, "SiteName")
            quoted = ", ".join(
                "'{}'".format(str(n).replace("'", "''")) for n in site_names
            )
            where = "{} IN ({})".format(field, quoted)
            with arcpy.da.SearchCursor(path, ["OID@"], where) as cursor:
                oids = [row[0] for row in cursor]

        if not oids:
            arcpy.management.SelectLayerByAttribute(
                layer, "CLEAR_SELECTION"
            )
        else:
            # SelectLayerByAttribute is primary because a geoprocessing
            # selection makes Pro repaint straight away, whereas
            # Layer.setSelectionSet() often doesn't redraw until the user
            # clicks. setSelectionSet is the fallback.
            oid_field = arcpy.AddFieldDelimiters(
                path, arcpy.Describe(path).OIDFieldName
            )
            oid_where = "{} IN ({})".format(
                oid_field, ", ".join(str(o) for o in oids)
            )
            try:
                arcpy.management.SelectLayerByAttribute(
                    layer, "NEW_SELECTION", oid_where
                )
            except Exception:
                layer.setSelectionSet(oids, "NEW")

        _refresh_map_display()

        _debug_logger.info(
            "Selected %d of %d requested site(s) in layer '%s'.",
            len(oids), len(site_names), getattr(layer, "name", "?"),
        )
        return True

    except Exception:
        _debug_logger.warning(
            "Could not select sites in the CollectionSites layer:\n%s",
            traceback.format_exc(),
        )
        return False


def _safe_filename_fragment(text):
    """Turn arbitrary text into a filesystem-safe fragment."""

    text = (text or "").strip()
    text = re.sub(r"[^A-Za-z0-9_\-]+", "_", text)
    return text.strip("_") or "output"


def _date_only(value):
    """
    Strip any time-of-day component from a GPDate parameter value, so the
    From/To pickers behave as date-only fields.
    """

    if value is None:
        return None

    if isinstance(value, datetime) and value.time() != datetime.min.time():
        return datetime(value.year, value.month, value.day)

    return value


def create_collection_sites_feature_class(
    council, collection_name, output_gdb, feature_class_name, extent_bounds=None
):
    """Create/replace a WGS84 point feature class for all locatable sites."""
    if not council or council not in COUNCIL_URLS:
        raise ValueError("Unknown council: {!r}".format(council))
    if not collection_name:
        raise ValueError("A collection must be selected.")
    if not output_gdb:
        raise ValueError("An output geodatabase must be selected.")
    if not feature_class_name or not feature_class_name.strip():
        raise ValueError("A collection feature class name is required.")

    feature_class_name = feature_class_name.strip()
    valid_name = arcpy.ValidateTableName(feature_class_name, output_gdb)
    if not valid_name:
        raise ValueError(
            "ArcGIS could not create a valid feature class name from {!r}."
            .format(feature_class_name)
        )
    feature_class_name = valid_name
    out_fc = os.path.join(output_gdb, feature_class_name)

    records = get_collection_site_records(
        council, collection_name, extent_bounds=extent_bounds
    )

    if arcpy.Exists(out_fc):
        arcpy.management.Delete(out_fc)

    arcpy.management.CreateFeatureclass(
        output_gdb,
        feature_class_name,
        "POINT",
        spatial_reference=_wgs84_spatial_reference(),
    )
    arcpy.management.AddField(out_fc, "SiteName", "TEXT", field_length=255)
    arcpy.management.AddField(out_fc, "Longitude", "DOUBLE")
    arcpy.management.AddField(out_fc, "Latitude", "DOUBLE")
    arcpy.management.AddField(out_fc, "CollectionName", "TEXT", field_length=255)
    arcpy.management.AddField(out_fc, "Council", "TEXT", field_length=255)

    with arcpy.da.InsertCursor(
        out_fc,
        ["SHAPE@XY", "SiteName", "Longitude", "Latitude", "CollectionName", "Council"],
    ) as cursor:
        for rec in records:
            cursor.insertRow(
                [
                    (rec["longitude"], rec["latitude"]),
                    rec["site_name"],
                    rec["longitude"],
                    rec["latitude"],
                    collection_name,
                    council,
                ]
            )

    _debug_logger.info(
        "Created collection feature class %r with %d site(s) for council=%s collection=%s extent_bounds=%r",
        out_fc, len(records), council, collection_name, extent_bounds,
    )
    return out_fc


def add_collection_sites_to_map(
    feature_class_path, map_destination, map_name=None, existing_map=None
):
    """Add a collection feature class to the requested ArcGIS Pro map."""
    if not feature_class_path or not arcpy.Exists(feature_class_path):
        raise ValueError(
            "Collection feature class does not exist: {!r}".format(
                feature_class_path
            )
        )

    aprx = arcpy.mp.ArcGISProject("CURRENT")
    target_map = None

    if map_destination == ImportHilltopCollectionSites._MAP_OPTION_NEW:
        requested_name = (map_name or "Hilltop Sites").strip() or "Hilltop Sites"
        target_map = aprx.createMap(requested_name)
        _set_map_spatial_reference_wgs84(target_map)
    else:
        if existing_map:
            matches = [m for m in aprx.listMaps() if m.name == existing_map]
            if matches:
                target_map = matches[0]
        if target_map is None:
            target_map = aprx.activeMap
        if target_map is None:
            requested_name = (map_name or "Hilltop Sites").strip() or "Hilltop Sites"
            target_map = aprx.createMap(requested_name)
            _set_map_spatial_reference_wgs84(target_map)

    # Don't add the same data source repeatedly while ArcGIS Pro calls
    # updateParameters() during dialog validation.
    collection_layer = _find_layer_by_datasource(target_map, feature_class_path)

    if collection_layer is None:
        collection_layer = target_map.addDataFromPath(feature_class_path)
        _debug_logger.info(
            "Added collection feature class %r to map %r",
            feature_class_path, target_map.name,
        )
    else:
        _debug_logger.info(
            "Collection feature class %r is already present in map %r",
            feature_class_path, target_map.name,
        )

    if collection_layer is not None:
        _apply_circle3_symbology(collection_layer)
        _apply_sitename_labels(collection_layer)

    return target_map


def get_collection_last_measurements(council, collection_name):
    """
    Download the GetData response for the named collection and return a
    list of dicts, one per <Measurement> element:

        {"site_name", "measurement", "units", "time", "value"}

    The last <E> entry inside <Data> is treated as the most recent
    recording.
    """

    cache_key = (council, collection_name)
    if cache_key in _LAST_MEASUREMENT_CACHE:
        return _LAST_MEASUREMENT_CACHE[cache_key]

    url = COUNCIL_URLS[council]["getdata"] + urllib.parse.quote(collection_name)

    root = _fetch_xml(url)

    records = []

    for meas in root.findall("Measurement"):

        site_name = meas.get("SiteName")
        if not site_name:
            continue

        data_source = meas.find("DataSource")
        measurement_name = (
            data_source.get("Name") if data_source is not None else None
        )

        units = None
        if data_source is not None:
            item_info = data_source.find("ItemInfo")
            if item_info is not None:
                units_elem = item_info.find("Units")
                if units_elem is not None and units_elem.text:
                    units = units_elem.text.strip()

        time_value = None
        value = None

        data_elem = meas.find("Data")

        if data_elem is not None:

            entries = data_elem.findall("E")

            if entries:
                last_entry = entries[-1]

                t_elem = last_entry.find("T")
                if t_elem is not None and t_elem.text:
                    t_text = t_elem.text.strip()
                    try:
                        time_value = datetime.fromisoformat(t_text)
                    except ValueError:
                        time_value = None

                i1_elem = last_entry.find("I1")
                if i1_elem is not None and i1_elem.text:
                    v_text = i1_elem.text.strip()
                    try:
                        value = float(v_text)
                    except ValueError:
                        value = None

        records.append(
            {
                "site_name": site_name,
                "measurement": measurement_name,
                "units": units,
                "time": time_value,
                "value": value,
            }
        )

    _LAST_MEASUREMENT_CACHE[cache_key] = records
    return records


def get_collection_timeseries(council, collection_name, from_date, to_date):
    """
    Download the full time series for a collection between two dates
    using a URL of the form:

        <getdata base>&Collection=<collection>&From=<d/m/Y>&To=<d/m/Y>

    Returns a list of dicts, one per <Measurement> element:

        {"site_name", "measurement", "units",
         "entries": [(datetime, float), ...], "url"}

    ALL <E> entries returned by the server are kept.
    """

    from_text = from_date.strftime(HILLTOP_DATE_FORMAT)
    to_text = to_date.strftime(HILLTOP_DATE_FORMAT)

    url = (
        COUNCIL_URLS[council]["getdata"]
        + urllib.parse.quote(collection_name)
        + "&From="
        + urllib.parse.quote(from_text)
        + "&To="
        + urllib.parse.quote(to_text)
    )

    root = _fetch_xml(url)

    records = []

    for meas in root.findall("Measurement"):

        site_name = meas.get("SiteName")
        if not site_name:
            continue

        data_source = meas.find("DataSource")
        measurement_name = (
            data_source.get("Name") if data_source is not None else None
        )

        units = None
        if data_source is not None:
            item_info = data_source.find("ItemInfo")
            if item_info is not None:
                units_elem = item_info.find("Units")
                if units_elem is not None and units_elem.text:
                    units = units_elem.text.strip()

        entries = []

        data_elem = meas.find("Data")

        if data_elem is not None:

            for e in data_elem.findall("E"):

                t_elem = e.find("T")
                i1_elem = e.find("I1")

                if t_elem is None or not t_elem.text:
                    continue

                t_text = t_elem.text.strip()
                try:
                    t_value = datetime.fromisoformat(t_text)
                except ValueError:
                    continue

                v_value = None
                if i1_elem is not None and i1_elem.text:
                    try:
                        v_value = float(i1_elem.text.strip())
                    except ValueError:
                        v_value = None

                entries.append((t_value, v_value))

        records.append(
            {
                "site_name": site_name,
                "measurement": measurement_name,
                "units": units,
                "entries": entries,
                "url": url,
            }
        )

    return records


# ---------------------------------------------------------------------------
# Toolbox
# ---------------------------------------------------------------------------

class Toolbox(object):
    def __init__(self):
        self.label = "Hilltop Tools"
        self.alias = "hilltoptools"
        self.tools = [ImportHilltopCollectionSites]


class ImportHilltopCollectionSites(object):
    def __init__(self):
        self.label = "Import Hilltop Collection Sites"
        self.description = (
            "Downloads a Hilltop monitoring collection from Horizons, "
            "GWRC, TRC, NRC, or Southland Regional Council and creates a "
            "point feature class containing only the selected sites. "
            "Selecting a council zooms the active map to that council's "
            "region. Selecting a collection adds all of the sites in that "
            "collection to the active map; sites selected in the tool are "
            "also selected on the map. Optionally saves the last "
            "recording and/or the full time series for a chosen date "
            "range to a table in the geodatabase "
            "(<Feature Class Name>_Recordings, linked to the sites by "
            "SiteName), and optionally exports the time series as a CSV. "
            "The feature class and table are added to an existing open "
            "map or to a brand new map."
        )
        self.canRunInBackground = False

    _MAP_OPTION_EXISTING = "Add to existing/open map"
    _MAP_OPTION_NEW = "Create new map"

    def getParameterInfo(self):

        # 0 - Council
        param_council = arcpy.Parameter(
            displayName=(
                "Council (the active map will zoom to the selected "
                "council's region)"
            ),
            name="council",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )
        param_council.filter.type = "ValueList"
        param_council.filter.list = COUNCIL_NAMES

        # 1 - Collection
        param_collection = arcpy.Parameter(
            displayName=(
                "Collection (all sites in the selected collection will "
                "be added to the active map)"
            ),
            name="collection",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )
        param_collection.filter.type = "ValueList"
        param_collection.filter.list = []

        # 2 - Collection Feature Class
        param_collection_fc = arcpy.Parameter(
            displayName="Collection Feature Class (NEW)",
            name="collection_feature_class",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )
        param_collection_fc.value = "CollectionSites"

        # 3 - Filter By Map Extent
        param_extent = arcpy.Parameter(
            displayName=(
                "Filter Measurements/Sites By Map Extent - WGS 1984 "
                "(optional; draw an extent on the map)"
            ),
            name="extent_filter",
            datatype="GPExtent",
            parameterType="Optional",
            direction="Input",
        )

        # 4 - Measurement
        param_measurement = arcpy.Parameter(
            displayName="Measurement (optional - filters the site list)",
            name="measurement",
            datatype="GPString",
            parameterType="Optional",
            direction="Input",
        )
        param_measurement.filter.type = "ValueList"
        param_measurement.filter.list = []

        # 5 - Sites (one-column value table: each row's dropdown commits as
        #     soon as a site is picked, so the map selection updates live)
        param_sites = arcpy.Parameter(
            displayName=(
                "Sites (add a row per site - the sites are also selected "
                "on the map as you pick them)"
            ),
            name="sites",
            datatype="GPValueTable",
            parameterType="Required",
            direction="Input",
        )
        param_sites.columns = [["GPString", "Site"]]
        param_sites.filters[0].type = "ValueList"
        param_sites.filters[0].list = []

        # 6 - Include Last Recording
        param_last = arcpy.Parameter(
            displayName=(
                "Include Last Recording In Table (units, time, value)"
            ),
            name="include_last_recording",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input",
        )
        param_last.value = True

        # 7 - New Map Name
        param_mapname = arcpy.Parameter(
            displayName="New Map Name (used when creating a new map)",
            name="map_name",
            datatype="GPString",
            parameterType="Optional",
            direction="Input",
        )
        param_mapname.value = "Hilltop Sites"

        # 8 - Map Destination
        param_mapdest = arcpy.Parameter(
            displayName="Map Destination",
            name="map_destination",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )
        param_mapdest.filter.type = "ValueList"
        param_mapdest.filter.list = [
            self._MAP_OPTION_EXISTING,
            self._MAP_OPTION_NEW,
        ]
        param_mapdest.value = self._MAP_OPTION_EXISTING

        # 9 - Existing Map
        param_existing_map = arcpy.Parameter(
            displayName="Existing Map (optional; blank uses active map)",
            name="existing_map",
            datatype="GPString",
            parameterType="Optional",
            direction="Input",
        )
        param_existing_map.filter.type = "ValueList"
        param_existing_map.filter.list = []

        # 10 - Download Full Time Series (master switch)
        param_daterange = arcpy.Parameter(
            displayName="Download Full Time Series For A Date Range",
            name="download_timeseries",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input",
        )
        param_daterange.value = False

        # 11 - From Date
        param_from_date = arcpy.Parameter(
            displayName="From Date (date only - any time is ignored)",
            name="from_date",
            datatype="GPDate",
            parameterType="Optional",
            direction="Input",
        )
        param_from_date.enabled = False

        # 12 - To Date
        param_to_date = arcpy.Parameter(
            displayName="To Date (date only - any time is ignored)",
            name="to_date",
            datatype="GPDate",
            parameterType="Optional",
            direction="Input",
        )
        param_to_date.enabled = False

        # 13 - Save Time Series To Table. The internal name and index are
        #      unchanged so nothing else in updateParameters/execute shifts;
        #      "want_ts_to_fc" in execute() now means "time series goes to
        #      the recordings table".
        param_ts_to_fc = arcpy.Parameter(
            displayName=(
                "Save Time Series To Table In Geodatabase "
                "(<Feature Class Name>_Recordings)"
            ),
            name="add_timeseries_to_feature_class",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input",
        )
        param_ts_to_fc.value = False
        param_ts_to_fc.enabled = False

        # 14 - Export Time Series To CSV
        param_export_csv = arcpy.Parameter(
            displayName="Export Time Series To CSV",
            name="export_timeseries_csv",
            datatype="GPBoolean",
            parameterType="Optional",
            direction="Input",
        )
        param_export_csv.value = True
        param_export_csv.enabled = False

        # 15 - CSV File Name
        param_csv_name = arcpy.Parameter(
            displayName=(
                "CSV File Name (optional; .csv added automatically; "
                "auto-generated if left blank)"
            ),
            name="csv_file_name",
            datatype="GPString",
            parameterType="Optional",
            direction="Input",
        )
        param_csv_name.enabled = False

        # 16 - CSV Output Folder
        param_csv_folder = arcpy.Parameter(
            displayName=(
                "CSV Output Folder (optional; defaults to the toolbox "
                "folder)"
            ),
            name="csv_output_folder",
            datatype="DEFolder",
            parameterType="Optional",
            direction="Input",
        )
        param_csv_folder.enabled = False

        # 17 - Output Geodatabase
        param_gdb = arcpy.Parameter(
            displayName="Output Geodatabase",
            name="output_gdb",
            datatype="DEWorkspace",
            parameterType="Required",
            direction="Input",
        )
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            if getattr(aprx, "defaultGeodatabase", None):
                param_gdb.value = aprx.defaultGeodatabase
        except Exception:
            pass

        # 18 - Feature Class Name
        param_fc = arcpy.Parameter(
            displayName="Feature Class Name (sites only)",
            name="feature_class_name",
            datatype="GPString",
            parameterType="Required",
            direction="Input",
        )

        return [
            param_council,
            param_collection,
            param_collection_fc,
            param_extent,
            param_measurement,
            param_sites,
            param_last,
            param_mapname,
            param_mapdest,
            param_existing_map,
            param_daterange,
            param_from_date,
            param_to_date,
            param_ts_to_fc,
            param_export_csv,
            param_csv_name,
            param_csv_folder,
            param_gdb,
            param_fc,
        ]

    def isLicensed(self):
        return True

    def updateParameters(self, parameters):
        global _INITIAL_FC_STATE

        # Parameter order (19 total):
        # 0 Council, 1 Collection, 2 Collection Feature Class (NEW),
        # 3 Extent Filter, 4 Measurement, 5 Sites, 6 Include Last Recording,
        # 7 New Map Name, 8 Map Destination, 9 Existing Map,
        # 10 Download Full Time Series, 11 From Date, 12 To Date,
        # 13 Save Time Series To Table, 14 Export Time Series To CSV,
        # 15 CSV File Name, 16 CSV Output Folder, 17 Output Geodatabase,
        # 18 Feature Class Name

        council = parameters[0]
        collection = parameters[1]
        collection_fc_param = parameters[2]
        extent = parameters[3]
        measurement = parameters[4]
        sites = parameters[5]
        include_last = parameters[6]
        map_name = parameters[7]
        map_destination = parameters[8]
        existing_map = parameters[9]
        download_ts = parameters[10]
        from_date = parameters[11]
        to_date = parameters[12]
        add_ts_fc = parameters[13]
        export_csv = parameters[14]
        csv_name = parameters[15]
        csv_folder = parameters[16]
        output_gdb = parameters[17]
        output_fc = parameters[18]

        current_council = council.valueAsText
        current_collection = collection.valueAsText

        # Council selection - zoom map
        if current_council != _ZOOM_STATE.get("council"):
            _ZOOM_STATE["council"] = current_council
            _INITIAL_FC_STATE["key"] = None
            _INITIAL_FC_STATE["path"] = None
            if current_council:
                council_extent = _get_council_extent_wgs84(current_council)
                if council_extent is not None:
                    _zoom_active_map_to_extent(council_extent)

        # Control enablement
        destination = map_destination.valueAsText or self._MAP_OPTION_EXISTING
        map_name.enabled = destination == self._MAP_OPTION_NEW
        existing_map.enabled = destination == self._MAP_OPTION_EXISTING

        want_ts = bool(download_ts.value)
        from_date.enabled = want_ts
        to_date.enabled = want_ts
        add_ts_fc.enabled = want_ts
        export_csv.enabled = want_ts

        want_csv = want_ts and bool(export_csv.value)
        csv_name.enabled = want_csv
        csv_folder.enabled = want_csv

        # The time series already includes the latest recording, so Last
        # Recording is switched off when the time series goes to the table.
        if want_ts and bool(add_ts_fc.value):
            include_last.value = False
            include_last.enabled = False
        else:
            include_last.enabled = True

        if not current_council:
            collection.filter.list = []
            collection.value = None
            measurement.filter.list = []
            measurement.value = None
            sites.filters[0].list = []
            sites.value = None
            return

        # Load collections
        try:
            collection_names = get_collection_names(current_council)
            if list(collection.filter.list) != collection_names:
                collection.filter.list = collection_names
            if current_collection not in collection_names:
                collection.value = None
                current_collection = None
        except Exception as exc:
            collection.filter.list = []
            collection.setErrorMessage("Could not load collections: {}".format(exc))
            return

        if not current_collection:
            measurement.filter.list = []
            measurement.value = None
            sites.filters[0].list = []
            sites.value = None
            return

        # Create CollectionSites immediately after BOTH Council and
        # Collection have been selected, so the collection-wide feature
        # class appears in the map while the dialog is still being
        # configured. The module-level state key prevents repeated
        # validation passes from recreating it.
        output_gdb_text = output_gdb.valueAsText
        collection_fc_name = (
            collection_fc_param.valueAsText or "CollectionSites"
        ).strip()

        collection_state_key = (
            current_council,
            current_collection,
            output_gdb_text,
            collection_fc_name,
        )

        if (
            output_gdb_text
            and current_council
            and current_collection
            and collection_state_key != _INITIAL_FC_STATE.get("key")
        ):
            try:
                arcpy.AddMessage(
                    "Creating CollectionSites for collection '{}'...".format(
                        current_collection
                    )
                )

                collection_fc_path = create_collection_sites_feature_class(
                    council=current_council,
                    collection_name=current_collection,
                    output_gdb=output_gdb_text,
                    feature_class_name=collection_fc_name,
                    extent_bounds=None,
                )

                collection_map = add_collection_sites_to_map(
                    feature_class_path=collection_fc_path,
                    map_destination=(
                        map_destination.valueAsText
                        or self._MAP_OPTION_EXISTING
                    ),
                    map_name=map_name.valueAsText,
                    existing_map=existing_map.valueAsText,
                )

                _INITIAL_FC_STATE["key"] = collection_state_key
                _INITIAL_FC_STATE["path"] = collection_fc_path
                _INITIAL_FC_STATE["map_name"] = collection_map.name
                _SELECTION_STATE["key"] = None

                arcpy.AddMessage(
                    "CollectionSites created and added to the map: {}".format(
                        collection_fc_path
                    )
                )

            except Exception as exc:
                # Don't mark the state complete when creation fails, so a
                # later updateParameters pass can retry.
                _INITIAL_FC_STATE["key"] = None
                _INITIAL_FC_STATE["path"] = None
                collection_fc_param.setErrorMessage(
                    "Could not create CollectionSites: {}".format(exc)
                )
                _debug_logger.error(
                    "Dynamic CollectionSites creation failed:\n%s",
                    traceback.format_exc(),
                )

        # Populate Measurement dropdown
        try:
            extent_bounds = get_extent_bounds_wgs84(extent.value)
        except Exception as exc:
            extent_bounds = None
            extent.setErrorMessage("Could not apply extent filter: {}".format(exc))

        try:
            measurement_names = get_measurements_for_collection(
                current_council,
                current_collection,
                extent_bounds=extent_bounds,
            )
            if list(measurement.filter.list) != measurement_names:
                measurement.filter.list = measurement_names
        except Exception as exc:
            measurement.filter.list = []
            measurement.setErrorMessage("Could not load measurements: {}".format(exc))

        selected_measurement = measurement.valueAsText
        if selected_measurement and selected_measurement not in measurement.filter.list:
            measurement.value = None
            selected_measurement = None

        # Populate Sites list
        try:
            site_names = get_sites_for_collection(
                current_council,
                current_collection,
                measurement=selected_measurement or None,
                extent_bounds=extent_bounds,
            )
            if list(sites.filters[0].list) != site_names:
                sites.filters[0].list = site_names
        except Exception as exc:
            sites.filters[0].list = []
            sites.setErrorMessage("Could not load sites: {}".format(exc))

        current_sites = _site_names_from_param(sites)
        if current_sites:
            valid_sites = [s for s in current_sites if s in site_names]
            if valid_sites != current_sites:
                sites.values = [[s] for s in valid_sites]

        # Mirror the Sites selection on the map (only when it changes).
        selected_site_names = _site_names_from_param(sites)
        selection_key = (
            collection_state_key, tuple(sorted(selected_site_names))
        )
        if (
            _INITIAL_FC_STATE.get("path")
            and selection_key != _SELECTION_STATE.get("key")
        ):
            if _select_sites_in_collection_layer(selected_site_names):
                _SELECTION_STATE["key"] = selection_key

        # Refresh existing map list
        try:
            aprx = arcpy.mp.ArcGISProject("CURRENT")
            map_names = sorted(
                [m.name for m in aprx.listMaps()],
                key=lambda v: v.lower(),
            )
            if list(existing_map.filter.list) != map_names:
                existing_map.filter.list = map_names
        except Exception:
            pass

    def updateMessages(self, parameters):

        param_council = parameters[0]
        param_collection = parameters[1]
        param_measurement = parameters[4]
        param_sites = parameters[5]
        param_last = parameters[6]
        param_mapname = parameters[7]
        param_mapdest = parameters[8]
        param_daterange = parameters[10]
        param_from_date = parameters[11]
        param_to_date = parameters[12]
        param_ts_to_fc = parameters[13]
        param_export_csv = parameters[14]

        # Explain why Last Recording is greyed out, when it is.
        if not param_last.enabled:
            param_last.setWarningMessage(
                "Turned off automatically because 'Save Time Series To "
                "Table' is selected - the time series already includes "
                "the latest recording."
            )
        else:
            param_last.clearMessage()

        # Council reminder.
        if not param_council.value:
            param_council.setErrorMessage(
                "Select a council to choose which Hilltop server to use."
            )
        else:
            param_council.clearMessage()

        # Collection dropdown reminder.
        if param_collection.filter.list and not param_collection.value:
            param_collection.setWarningMessage(
                "Select a collection from the dropdown."
            )
        else:
            param_collection.clearMessage()

        # Measurement hint.
        if param_collection.value and not param_measurement.value:
            param_measurement.setWarningMessage(
                "Optional: pick a measurement to filter the site list. "
                "Leave empty to list all sites in the collection."
            )
        else:
            param_measurement.clearMessage()

        # Sites: at least one must be selected. Otherwise tell the user
        # how many collection sites are hidden for lack of a location.
        if param_collection.value and not _site_names_from_param(param_sites):
            param_sites.setErrorMessage(
                "Select at least one site from the list."
            )
        else:
            missing_count = 0
            if param_council.value and param_collection.value:
                try:
                    current_measurement_text = param_measurement.valueAsText
                    raw_items = get_collection_items(
                        param_council.value, param_collection.value
                    )
                    raw_normalized = {
                        _normalize_site_name(s)
                        for s, m in raw_items
                        if s and (
                            not current_measurement_text
                            or m == current_measurement_text
                        )
                    }
                    locatable_records = get_collection_site_records(
                        param_council.value,
                        param_collection.value,
                        measurement=current_measurement_text or None,
                    )
                    locatable_normalized = {
                        _normalize_site_name(r["site_name"])
                        for r in locatable_records
                    }
                    missing_count = len(raw_normalized) - len(
                        locatable_normalized
                    )
                except Exception:
                    missing_count = 0

            if missing_count > 0:
                param_sites.setWarningMessage(
                    "{} site(s) in this collection have no known "
                    "location in the Hilltop SiteList and are not "
                    "shown.".format(missing_count)
                )
            else:
                param_sites.clearMessage()

        # New map name is only relevant when creating a new map.
        if (
            param_mapdest.valueAsText == self._MAP_OPTION_NEW
            and not param_mapname.valueAsText
        ):
            param_mapname.setWarningMessage(
                "A new map will be created with the default name "
                "'Hilltop Sites' if this is left blank."
            )
        else:
            param_mapname.clearMessage()

        # --- Date-range time series checks / warnings ----------------------
        if param_daterange.value:

            if not param_from_date.value or not param_to_date.value:
                param_to_date.setErrorMessage(
                    "Select both a From Date and a To Date to download the "
                    "time series."
                )
                param_from_date.clearMessage()

            elif param_from_date.value > param_to_date.value:
                param_to_date.setErrorMessage(
                    "To Date must be on or after From Date."
                )
                param_from_date.clearMessage()

            else:
                span_days = (
                    param_to_date.value - param_from_date.value
                ).days

                if span_days >= VERY_LONG_RANGE_WARNING_DAYS:
                    param_to_date.setWarningMessage(
                        "Date range is {} days. This is a large request and "
                        "will take a long time to collect the data - "
                        "consider narrowing the range if possible.".format(
                            span_days
                        )
                    )
                elif span_days >= LONG_RANGE_WARNING_DAYS:
                    param_to_date.setWarningMessage(
                        "Date range is {} days. Longer time frames take "
                        "longer to collect the data.".format(span_days)
                    )
                else:
                    param_to_date.setWarningMessage(
                        "Downloading a full time series - this may take a "
                        "little while depending on how much data is "
                        "returned."
                    )
                param_from_date.clearMessage()

            # At least one destination for the downloaded data must be on.
            if not param_ts_to_fc.value and not param_export_csv.value:
                param_export_csv.setErrorMessage(
                    "Select at least one destination for the time series: "
                    "'Save Time Series To Table' and/or "
                    "'Export Time Series To CSV'."
                )
            else:
                param_export_csv.clearMessage()

        else:
            param_from_date.clearMessage()
            param_to_date.clearMessage()
            param_export_csv.clearMessage()

        return

    def execute(self, parameters, messages):

        # Keep everything this tool creates in WGS 1984.
        arcpy.env.outputCoordinateSystem = _wgs84_spatial_reference()

        council = parameters[0].valueAsText
        collection_name = parameters[1].valueAsText
        collection_fc_name = parameters[2].valueAsText or "CollectionSites"
        # parameters[3] (extent filter) only affects the dialog lists.
        measurement_tag = parameters[4].valueAsText
        include_last = str(parameters[6].valueAsText).strip().lower() == "true"
        map_name = parameters[7].valueAsText
        map_destination = parameters[8].valueAsText or self._MAP_OPTION_EXISTING
        existing_map = parameters[9].valueAsText
        want_timeseries = (
            str(parameters[10].valueAsText).strip().lower() == "true"
        )
        from_date_value = _date_only(parameters[11].value)
        to_date_value = _date_only(parameters[12].value)
        # want_ts_to_fc: the time series goes to the recordings TABLE.
        want_ts_to_fc = (
            want_timeseries
            and str(parameters[13].valueAsText).strip().lower() == "true"
        )
        want_export_csv = (
            want_timeseries
            and str(parameters[14].valueAsText).strip().lower() == "true"
        )
        csv_file_name = parameters[15].valueAsText
        csv_folder = parameters[16].valueAsText
        gdb = parameters[17].valueAsText
        fc_name = parameters[18].valueAsText

        if not council:
            arcpy.AddError("Select a council to choose which Hilltop server to use.")
            raise ValueError("No council selected")
        if not collection_name:
            arcpy.AddError("Select a collection.")
            raise ValueError("No collection selected")

        # Safety net for saved settings / command-line runs where the
        # dialog logic never ran. The time series table wins over Last
        # Recording.
        if want_ts_to_fc and include_last:
            arcpy.AddWarning(
                "Both 'Include Last Recording' and 'Save Time Series To "
                "Table' were set - ignoring Last Recording since the time "
                "series already includes the latest recording."
            )
            include_last = False

        if not map_name:
            map_name = "Hilltop Sites"
        if not gdb:
            arcpy.AddError("Select an output geodatabase.")
            raise ValueError("No output geodatabase selected")
        if not fc_name:
            fc_name = "HilltopSites"

        out_fc = os.path.join(gdb, fc_name)

        # ------------------------------------------------------------------
        # Collection-wide CollectionSites feature class (reused if the
        # dialog already created it, otherwise created here).
        # ------------------------------------------------------------------

        collection_fc_name = (parameters[2].valueAsText or "CollectionSites").strip()
        collection_fc_valid_name = arcpy.ValidateTableName(collection_fc_name, gdb)
        if not collection_fc_valid_name:
            arcpy.AddError("ArcGIS could not create a valid Collection Feature Class name from {!r}.".format(collection_fc_name))
            raise ValueError("Invalid collection feature class name")

        collection_fc_path = os.path.join(gdb, collection_fc_valid_name)

        if os.path.normcase(os.path.normpath(collection_fc_path)) == os.path.normcase(os.path.normpath(out_fc)):
            arcpy.AddError("Collection Feature Class and Feature Class must have different names.")
            raise ValueError("Collection feature class conflicts with output feature class")

        execute_collection_state_key = (
            council, collection_name, gdb, collection_fc_name
        )

        try:
            if (
                _INITIAL_FC_STATE.get("key") == execute_collection_state_key
                and _INITIAL_FC_STATE.get("path")
                and arcpy.Exists(_INITIAL_FC_STATE["path"])
            ):
                collection_fc_path = _INITIAL_FC_STATE["path"]
                arcpy.AddMessage(
                    "Using existing CollectionSites feature class '{}'.".format(
                        collection_fc_path
                    )
                )
            else:
                arcpy.AddMessage(
                    "Creating collection feature class '{}'...".format(
                        collection_fc_valid_name
                    )
                )
                collection_fc_path = create_collection_sites_feature_class(
                    council=council,
                    collection_name=collection_name,
                    output_gdb=gdb,
                    feature_class_name=collection_fc_valid_name,
                    extent_bounds=None,
                )
                _INITIAL_FC_STATE["key"] = execute_collection_state_key
                _INITIAL_FC_STATE["path"] = collection_fc_path
                arcpy.AddMessage(
                    "Created collection feature class '{}'.".format(
                        collection_fc_path
                    )
                )
        except Exception:
            logging.error(traceback.format_exc())
            arcpy.AddError("Could not create the CollectionSites feature class.")
            raise

        # ------------------------------------------------------------------
        # Parse the selected sites. Use the parameter's .values (a real
        # list); splitting valueAsText on ";" would leave the quotes ArcGIS
        # Pro adds around names with spaces attached, so names would never
        # match and the outputs would be empty.
        # ------------------------------------------------------------------

        sites_param = parameters[5]
        selected_sites = _site_names_from_param(sites_param)
        if not selected_sites:
            sites_text = sites_param.valueAsText or ""
            selected_sites = [
                s.strip().strip("'\"")
                for s in sites_text.split(";")
                if s.strip()
            ]

        selected_sites = list(dict.fromkeys(selected_sites))

        if not selected_sites:
            arcpy.AddError("Select at least one site from the list.")
            raise ValueError("No sites selected")

        target_datasource = _datasource_name_from_measurement_tag(
            measurement_tag
        )

        # ------------------------------------------------------------------
        # Logging Setup
        # ------------------------------------------------------------------

        log_folder = os.path.dirname(__file__)

        run_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        log_file = os.path.join(
            log_folder,
            "HilltopCollectionSites_{0}.log".format(run_stamp),
        )

        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            force=True,
        )

        logging.info("Tool started")
        logging.info("Council: %s", council)
        logging.info("Collection: %s", collection_name)
        logging.info("Collection feature class: %s", collection_fc_name)
        logging.info("Measurement: %s", measurement_tag)
        logging.info("DataSource match: %s", target_datasource)
        logging.info("Selected sites: %s", selected_sites)
        logging.info("Include last recording: %s", include_last)
        logging.info("Map destination: %s", map_destination)
        logging.info("Existing map: %s", existing_map)
        logging.info("New map name: %s", map_name)
        logging.info("Download timeseries: %s", want_timeseries)
        logging.info("From date: %s", from_date_value)
        logging.info("To date: %s", to_date_value)
        logging.info("Save timeseries to table: %s", want_ts_to_fc)
        logging.info("Export timeseries to CSV: %s", want_export_csv)
        logging.info("CSV file name: %s", csv_file_name)
        logging.info("CSV folder: %s", csv_folder)
        logging.info("Output geodatabase: %s", gdb)
        logging.info("Feature class name: %s", fc_name)

        if want_timeseries and not want_ts_to_fc and not want_export_csv:
            arcpy.AddError(
                "Select at least one destination for the time series: "
                "'Save Time Series To Table' and/or "
                "'Export Time Series To CSV'."
            )
            raise ValueError("No time series destination selected")

        # ------------------------------------------------------------------
        # Download the site coordinate list (always needed)
        # ------------------------------------------------------------------

        try:

            arcpy.AddMessage(
                "Downloading {} site coordinates...".format(council)
            )
            logging.info("Downloading: %s", COUNCIL_URLS[council]["sites"])

            coord_lookup_raw = get_site_coordinates(council)
            coord_lookup = {
                _normalize_site_name(name): latlon
                for name, latlon in coord_lookup_raw.items()
            }

            logging.info("Loaded %s site coordinates", len(coord_lookup_raw))
            arcpy.AddMessage(
                "Loaded {} site coordinates.".format(len(coord_lookup_raw))
            )

        except Exception:

            logging.error(traceback.format_exc())
            arcpy.AddError(
                "Failed to download or parse the site coordinate list."
            )
            raise

        # ------------------------------------------------------------------
        # Download the time series up front (if requested) so it is
        # available both for the table and for the CSV export.
        # ------------------------------------------------------------------

        ts_records = None
        ts_span_days = None

        if want_timeseries:

            if not from_date_value or not to_date_value:
                arcpy.AddError(
                    "Select both a From Date and a To Date to download the "
                    "time series."
                )
                raise ValueError("Missing From/To date")

            if from_date_value > to_date_value:
                arcpy.AddError("To Date must be on or after From Date.")
                raise ValueError("From Date is after To Date")

            ts_span_days = (to_date_value - from_date_value).days

            if ts_span_days >= VERY_LONG_RANGE_WARNING_DAYS:
                arcpy.AddWarning(
                    "Date range is {} days - this is a large request and "
                    "will take a long time to collect the data.".format(
                        ts_span_days
                    )
                )
            elif ts_span_days >= LONG_RANGE_WARNING_DAYS:
                arcpy.AddWarning(
                    "Date range is {} days - longer time frames take "
                    "longer to collect the data.".format(ts_span_days)
                )

            from_text = from_date_value.strftime(HILLTOP_DATE_FORMAT)
            to_text = to_date_value.strftime(HILLTOP_DATE_FORMAT)

            try:

                arcpy.AddMessage(
                    "Downloading time series for collection '{}' ({}) "
                    "from {} to {}. This may take a while...".format(
                        collection_name, council, from_text, to_text
                    )
                )

                ts_records = get_collection_timeseries(
                    council, collection_name, from_date_value, to_date_value
                )

                logging.info(
                    "Timeseries request URL: %s",
                    ts_records[0]["url"] if ts_records else "(no records)",
                )
                arcpy.AddMessage(
                    "Time series download complete ({} measurement "
                    "record(s)).".format(len(ts_records))
                )

            except Exception:

                logging.error(traceback.format_exc())
                arcpy.AddError(
                    "Failed to download or parse the time series data."
                )
                raise

        selected_normalized_set = {
            _normalize_site_name(s) for s in selected_sites
        }

        # Pre-filter the time series to the selected sites / measurement
        # into a flat list used by both the table rows and the CSV rows.
        ts_filtered_entries = []

        if ts_records is not None:
            for rec in ts_records:

                if _normalize_site_name(rec["site_name"]) not in selected_normalized_set:
                    continue

                if (
                    target_datasource
                    and rec["measurement"] != target_datasource
                ):
                    continue

                for entry_time, entry_value in rec["entries"]:
                    ts_filtered_entries.append(
                        {
                            "site_name": rec["site_name"],
                            "measurement": rec["measurement"],
                            "units": rec["units"],
                            "time": entry_time,
                            "value": entry_value,
                        }
                    )

        # ------------------------------------------------------------------
        # Build site rows (feature class: ONE point per selected site) and
        # recording rows (table: all recordings, keyed by SiteName)
        # ------------------------------------------------------------------

        site_rows = []
        for site_name in selected_sites:
            coords = coord_lookup.get(_normalize_site_name(site_name))
            if coords is None:
                logging.warning(
                    "Site '%s' not found in coordinate list", site_name
                )
                continue
            lat, lon = coords
            site_rows.append(
                {
                    "shape": (lon, lat),
                    "site_name": site_name,
                    "longitude": lon,
                    "latitude": lat,
                }
            )

        recording_rows = []

        if include_last:
            try:
                arcpy.AddMessage(
                    "Downloading last recording for collection "
                    "'{}' ({})...".format(collection_name, council)
                )
                logging.info(
                    "Downloading: %s%s",
                    COUNCIL_URLS[council]["getdata"],
                    urllib.parse.quote(collection_name),
                )
                last_measurements = get_collection_last_measurements(
                    council, collection_name
                )
                logging.info(
                    "Collection has %s measurement record(s)",
                    len(last_measurements),
                )
                arcpy.AddMessage(
                    "Collection '{}' contains {} measurement "
                    "record(s).".format(
                        collection_name, len(last_measurements)
                    )
                )
            except Exception:
                logging.error(traceback.format_exc())
                arcpy.AddError(
                    "Failed to download or parse the collection "
                    "measurements."
                )
                raise

            for m in last_measurements:
                if _normalize_site_name(m["site_name"]) not in selected_normalized_set:
                    continue
                if target_datasource and m["measurement"] != target_datasource:
                    continue
                recording_rows.append(
                    {
                        "site_name": m["site_name"],
                        "measurement": m["measurement"],
                        "units": m["units"],
                        "time": m["time"],
                        "value": m["value"],
                    }
                )

        if want_ts_to_fc:
            for entry in ts_filtered_entries:
                recording_rows.append(
                    {
                        "site_name": entry["site_name"],
                        "measurement": entry["measurement"],
                        "units": entry["units"],
                        "time": entry["time"],
                        "value": entry["value"],
                    }
                )
            arcpy.AddMessage(
                "{} time series recording(s) will be added to the "
                "table.".format(len(ts_filtered_entries))
            )

        # ------------------------------------------------------------------
        # Create the sites-only feature class
        # ------------------------------------------------------------------

        try:
            if arcpy.Exists(out_fc):
                arcpy.management.Delete(out_fc)

            arcpy.management.CreateFeatureclass(
                gdb, fc_name, "POINT",
                spatial_reference=_wgs84_spatial_reference(),
            )
            arcpy.management.AddField(out_fc, "SiteName", "TEXT", field_length=255)
            arcpy.management.AddField(out_fc, "Longitude", "DOUBLE")
            arcpy.management.AddField(out_fc, "Latitude", "DOUBLE")
            arcpy.management.AddField(out_fc, "CollectionName", "TEXT", field_length=255)
            arcpy.management.AddField(out_fc, "Council", "TEXT", field_length=255)

            count = 0
            with arcpy.da.InsertCursor(
                out_fc,
                ["SHAPE@XY", "SiteName", "Longitude", "Latitude",
                 "CollectionName", "Council"],
            ) as cursor:
                for row in site_rows:
                    cursor.insertRow(
                        [row["shape"], row["site_name"], row["longitude"],
                         row["latitude"], collection_name, council]
                    )
                    count += 1

            arcpy.AddMessage("Imported {} site(s).".format(count))
            logging.info("Imported %s site(s)", count)

        except Exception:
            logging.error(traceback.format_exc())
            arcpy.AddError("Feature class creation failed.")
            raise

        # ------------------------------------------------------------------
        # Create the recordings table (SiteName links it to the sites FC)
        # ------------------------------------------------------------------

        recordings_table = None

        if include_last or want_ts_to_fc:
            try:
                table_name = arcpy.ValidateTableName(
                    fc_name + "_Recordings", gdb
                )
                recordings_table = os.path.join(gdb, table_name)

                if arcpy.Exists(recordings_table):
                    arcpy.management.Delete(recordings_table)

                arcpy.management.CreateTable(gdb, table_name)
                arcpy.management.AddField(recordings_table, "SiteName", "TEXT", field_length=255)
                arcpy.management.AddField(recordings_table, "MeasurementName", "TEXT", field_length=255)
                arcpy.management.AddField(recordings_table, "Units", "TEXT", field_length=50)
                arcpy.management.AddField(recordings_table, "MeasurementTime", "DATE")
                arcpy.management.AddField(recordings_table, "MeasurementValue", "DOUBLE")
                arcpy.management.AddField(recordings_table, "CollectionName", "TEXT", field_length=255)
                arcpy.management.AddField(recordings_table, "Council", "TEXT", field_length=255)

                t_count = 0
                t_skipped = 0
                with arcpy.da.InsertCursor(
                    recordings_table,
                    ["SiteName", "MeasurementName", "Units",
                     "MeasurementTime", "MeasurementValue",
                     "CollectionName", "Council"],
                ) as cursor:
                    for r in recording_rows:
                        try:
                            cursor.insertRow(
                                [r["site_name"], r["measurement"], r["units"],
                                 r["time"], r["value"],
                                 collection_name, council]
                            )
                            t_count += 1
                        except Exception:
                            t_skipped += 1
                            logging.error(
                                "Failed table row for site '%s'\n%s",
                                r.get("site_name"), traceback.format_exc(),
                            )

                arcpy.AddMessage(
                    "Recordings table '{}': {} row(s), {} skipped.".format(
                        table_name, t_count, t_skipped
                    )
                )
                logging.info("Recordings table %s: %s rows", recordings_table, t_count)

            except Exception:
                logging.error(traceback.format_exc())
                arcpy.AddError("Recordings table creation failed.")
                raise

        # ------------------------------------------------------------------
        # Optional: export the (already downloaded / filtered) time series
        # to a CSV file, at a location and with a name the user controls.
        # ------------------------------------------------------------------

        if want_export_csv:

            try:

                out_folder = csv_folder if csv_folder else log_folder

                if not os.path.isdir(out_folder):
                    arcpy.AddWarning(
                        "CSV output folder '{}' does not exist - using "
                        "the toolbox folder instead.".format(out_folder)
                    )
                    out_folder = log_folder

                if csv_file_name and csv_file_name.strip():
                    base_name = _safe_filename_fragment(
                        os.path.splitext(csv_file_name.strip())[0]
                    )
                else:
                    base_name = "HilltopTimeSeries_{}_{}_{}".format(
                        _safe_filename_fragment(council),
                        _safe_filename_fragment(collection_name),
                        run_stamp,
                    )

                csv_path = os.path.join(out_folder, base_name + ".csv")

                # Don't silently overwrite an existing file.
                suffix = 1
                original_csv_path = csv_path
                while os.path.exists(csv_path):
                    csv_path = "{}_{}.csv".format(
                        os.path.splitext(original_csv_path)[0], suffix
                    )
                    suffix += 1

                with open(csv_path, "w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow(
                        [
                            "SiteName",
                            "Measurement",
                            "Units",
                            "DateTime",
                            "Value",
                            "Council",
                        ]
                    )
                    for entry in ts_filtered_entries:
                        writer.writerow(
                            [
                                entry["site_name"],
                                entry["measurement"],
                                entry["units"],
                                entry["time"].isoformat()
                                if entry["time"] else "",
                                entry["value"],
                                council,
                            ]
                        )

                arcpy.AddMessage(
                    "Time series exported: {} rows.".format(
                        len(ts_filtered_entries)
                    )
                )
                arcpy.AddMessage("Time Series CSV:")
                arcpy.AddMessage(csv_path)

                logging.info(
                    "Time series CSV written with %s rows: %s",
                    len(ts_filtered_entries),
                    csv_path,
                )

            except Exception:

                logging.error(traceback.format_exc())
                arcpy.AddWarning(
                    "Failed to export the time series CSV. See log file "
                    "for details."
                )

        # ------------------------------------------------------------------
        # Add To Map (existing open map or brand new map)
        # ------------------------------------------------------------------

        try:

            aprx = arcpy.mp.ArcGISProject("CURRENT")

            target_map = None

            if map_destination == self._MAP_OPTION_NEW:

                target_map = aprx.createMap(map_name)
                _set_map_spatial_reference_wgs84(target_map)

                arcpy.AddMessage(
                    "Created new map '{}'.".format(target_map.name)
                )
                logging.info("Created new map '%s'", target_map.name)

            else:

                if existing_map:
                    matches = [
                        m for m in aprx.listMaps()
                        if m.name == existing_map
                    ]
                    if matches:
                        target_map = matches[0]
                    else:
                        arcpy.AddWarning(
                            "Selected map '{}' was not found. Using the "
                            "active map if available.".format(
                                existing_map
                            )
                        )

                if target_map is None:
                    target_map = aprx.activeMap

                if target_map is None:
                    target_map = aprx.createMap(map_name)
                    _set_map_spatial_reference_wgs84(target_map)
                    arcpy.AddWarning(
                        "No active or selected open map found. "
                        "Created new map '{}'.".format(target_map.name)
                    )
                    logging.warning(
                        "No active/selected map found; created '%s'",
                        target_map.name,
                    )
                else:
                    arcpy.AddMessage(
                        "Using existing map '{}'.".format(
                            target_map.name
                        )
                    )
                    logging.info(
                        "Using existing map '%s'", target_map.name
                    )

            # CollectionSites first (it may already have been added by
            # updateParameters(), so avoid a duplicate layer), then the
            # selected-site output layer, then the recordings table.
            collection_layer = _find_layer_by_datasource(
                target_map, collection_fc_path
            )

            if collection_layer is None:
                collection_layer = target_map.addDataFromPath(collection_fc_path)
                arcpy.AddMessage(
                    "Added CollectionSites feature class '{}' to map '{}'.".format(
                        collection_fc_path, target_map.name
                    )
                )
                logging.info(
                    "Added collection feature class '%s' to map '%s'",
                    collection_fc_path, target_map.name,
                )
            else:
                arcpy.AddMessage(
                    "CollectionSites is already present in map '{}'.".format(
                        target_map.name
                    )
                )

            if collection_layer is not None:
                _apply_circle3_symbology(collection_layer)
                _apply_sitename_labels(collection_layer)

            # Leave the selected sites highlighted in CollectionSites.
            _INITIAL_FC_STATE["map_name"] = target_map.name
            _select_sites_in_collection_layer(selected_sites)

            target_map.addDataFromPath(out_fc)

            arcpy.AddMessage(
                "Added feature class '{}' to map '{}'.".format(
                    fc_name, target_map.name
                )
            )
            logging.info(
                "Added feature class '%s' to map '%s'",
                fc_name,
                target_map.name,
            )

            if recordings_table and arcpy.Exists(recordings_table):
                if _find_table_by_datasource(target_map, recordings_table) is None:
                    try:
                        target_map.addTable(arcpy.mp.Table(recordings_table))
                    except Exception:
                        # Fallback: addDataFromPath also accepts tables.
                        logging.warning(
                            "addTable failed, trying addDataFromPath:\n%s",
                            traceback.format_exc(),
                        )
                        target_map.addDataFromPath(recordings_table)
                arcpy.AddMessage(
                    "Added table '{}' to map '{}'.".format(
                        os.path.basename(recordings_table), target_map.name
                    )
                )
                logging.info(
                    "Added table '%s' to map '%s'",
                    recordings_table, target_map.name,
                )

        except Exception:

            logging.error(traceback.format_exc())
            arcpy.AddWarning(
                "Unable to add the feature class/table to the map. "
                "See log file for details."
            )

        # ------------------------------------------------------------------
        # Finish
        # ------------------------------------------------------------------

        logging.info("Tool completed")

        arcpy.AddMessage("")
        arcpy.AddMessage("Log File:")
        arcpy.AddMessage(log_file)
